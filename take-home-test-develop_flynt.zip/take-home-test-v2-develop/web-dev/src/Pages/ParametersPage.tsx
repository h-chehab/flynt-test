export function ParametersPages(): JSX.Element {
  return (
    <div id="home-pages">
      <h1>PARAMETERS PAGE</h1>
      <span>Might be useful later</span>
    </div>
  );
}
