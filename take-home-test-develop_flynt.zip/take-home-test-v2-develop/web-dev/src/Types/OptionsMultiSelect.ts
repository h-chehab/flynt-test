export interface OptionsMultiSelectType {
  id: number;
  label: string;
}
